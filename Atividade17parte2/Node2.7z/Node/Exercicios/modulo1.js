var texto = "Observar que essa mensagem vem do módulo";
module.exports = texto;
