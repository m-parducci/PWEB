var eventos = require('events');
// atribuição da classe EventEmitter a uma variavel

var EmissorEventos = eventos.EventEmitter;

//criação de uma instancia do EventEmitter variavel

var ee = new EmissorEventos();

//criando sem a variavel intermediaria:
//mas da forma criada anteriormente eh uma boa pratica
var ee = new eventos.EventEmitter();

//é registrado um ouvinte (listener) para o evento 'dados'.
//quando esse evento eh emitido, a função passada com argumento imprime no console o valor recebido
ee.on('dados', function (fecha) {
    console.log(fecha);
});

setInterval(function () {
    ee.emit('dados', Date.now());
}, 500);