function exibeMensagensNaOrdem(mensagem, callback) {
    console.log(mensagem);
    callback();
}

exibeMensagensNaOrdem('Essa eh a primeira mensagem', function () {
    console.log('Essa eh a segunda mensagem exibida na ordem')
})